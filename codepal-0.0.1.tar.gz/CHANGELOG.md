### Features:

- Added CodePal extension walkthrough guide.
- Added Settings entry.
- Added status bar item.
- Added Automatic/Manual completion trigger modes.
- Added ability to show trigger mode in status bar.
- Added a way to switch trigger modes from status bar.
- Added relevant commands.
- Added Notifications.

### Fixes:

- Fixed wrongs hole, start and end formatting.