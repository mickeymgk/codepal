# Code Completion

## Basic Usage

CodePal will show inline suggestions when you stop typing, and you can accept suggestions by just pressing the `Tab` key.

![Demo](https://github.com/mickeymgk/codepal/assets/demo.gif)

## Manual Trigger

If you select manual trigger in the [settings](command:codepal.openSettings), you can trigger code completion by pressing `Alt + \`.
