## Finding Your Cloudflare Account ID in Workers & Pages

This guide details the steps to locate your Account ID within the Cloudflare's Workers & Pages platform.

1. **Navigate to the Workers & Pages Dashboard**

2. **Access the Overview Section:**
    * From the left sidebar select "Workers and Pages" then click on "Overview".

3. **Find Account Details:**
    * Within the Overview section, on the right side Under the "Account details" you find a section labled "Account ID.
    * Copy your "Account ID" and paste it here by clicking "Specify Account ID"
