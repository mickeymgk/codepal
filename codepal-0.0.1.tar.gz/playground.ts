const message: string = "Hello, from CodePal!";

const heading = document.createElement("h1");
heading.textContent = message;
